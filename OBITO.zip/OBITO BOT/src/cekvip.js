const cekvip = () => {
	return `
──────────────────
*Nome do bot* :  OBITO BOT
──────────────────
『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *STATUS*    : *ATIVO*
──────────────────
*STATUS DO BOT:* *Online*
──────────────────

*VOCE É UM MEMBRO PREMIUM* ⚡🚩`
}
exports.cekvip = cekvip
