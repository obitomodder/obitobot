const addsay = () => { 
	return `
	
	*Adicionar mensagem*
	
	Mensagem salva
	

obrigado !`
}
exports.addsay = addsay