const iklan = () => {
	return `
╔══✪〘 OBITO 〙✪══
║
╠═══════════════════════════
╠➥ *LISTA DE ALUGUEL E CRIAR BOTS:*
╠➥ *CRIAR: 10 (PODE SER PROPRIETÁRIO)*
╠➥ *PODE PAGAR ATRAVÉS DE:*
╠➥ *MERCADO PAGO, BOLETO, PAYPAL ETC*
╠═══════════════════════════
╠➥ *PARA MAIS VANTAGENS ME CHAME*
╠➥ *wa.me/5517981992106*
║
╚═〘  OBITO  〙
`
}
exports.iklan = iklan
