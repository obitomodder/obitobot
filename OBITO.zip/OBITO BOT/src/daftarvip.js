const daftarvip = (prefix) => {
	return `

*PREÇO DE LISTA VIP :*

-R$. 5 > Acessar recursos VIP
-R$. 10 > Recursos VIP + Personalize seu BOT!

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/5517981992106 ou digite *${prefix}owner*_

*NOTA*

*GRUPO DO OBITO 🐊🚩 :*
_https://chat.whatsapp.com/FhgyLPArxnvJgzgFK8vRLY_ `
}
exports.daftarvip = daftarvip
